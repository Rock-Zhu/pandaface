CKEditor SyntaxHighlighter Integration module
=============================================

This module will create a "code" button to integrate
SyntaxHighlighter by http://alexgorbatchev.com/SyntaxHighlighter
plugin to CKEditor.

You will need to download & install :
1. CKEditor : http://drupal.org/project/ckeditor.
2. SyntaxHighlighter : http://drupal.org/project/syntaxhighlighter.
3. CKEditor js library - Read CKEditor module readme file.
4. SyntaxHighlighter js library - Read SyntaxHighlighter readme file.

Then Install this module as usual, configure ckeditor at :
 admin/config/content/ckeditor/edit/Full (or Advance)
 
and enable the syntaxhighlighter button for ckeditor.

The module comes with js script from : 
http://code.google.com/p/ckeditor-syntaxhighlight

and inspired from its installation instruction :
http://code.google.com/p/ckeditor-syntaxhighlight/wiki/Installation (comment by  MarcosHe...@gmail.com)

Have fun!.