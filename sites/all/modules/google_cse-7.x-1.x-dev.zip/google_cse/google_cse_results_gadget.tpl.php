<?php
?>

<div id="google-cse-results-gadget">
  <a href="http://fusion.google.com/add?moduleurl=http%3A%2F%2Fwww.google.com%2Fcoop/api/<?php print $creator; ?>/cse/<?php print $id; ?>/gadget">
    <img src="https://www.google.com/ig/images/plus_google.gif" width="62" height="17" border="0" alt="<?php print t('Add to Google'); ?>" />
  </a>
</div>
