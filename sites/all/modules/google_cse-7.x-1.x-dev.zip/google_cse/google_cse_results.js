var googleSearchIframeName = 'google-cse-results';
var googleSearchFormName = 'google-cse-results-searchbox-form';
var googleSearchFrameWidth = Drupal.settings.googleCSE.resultsWidth;
var googleSearchFrameborder = 0;
var googleSearchDomain = Drupal.settings.googleCSE.domain;
var googleSearchPath = '/cse';
var googleSearchQueryString = 'query';
