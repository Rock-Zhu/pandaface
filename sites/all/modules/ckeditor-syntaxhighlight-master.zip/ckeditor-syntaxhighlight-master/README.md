# ckeditor-syntaxhighlight
A plugin for CKEditor 3+ that enabled code syntax highlighting. Mostly abandoned by owner (sorry), as it was just hacked out for a project I was working on at the time.

# CKEditor 4 support
There's a ckeditor-4 branch with german language ported by s.ziegltrum, completely untested by me. Check it out.
